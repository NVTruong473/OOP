public class TestBai3{
    public static void main(String [] args){
        Point2D point2d1 = new Point2D();
        Point2D point2d = new Point2D(2, 2);

        System.out.println(point2d);

        Point3D point3d1 = new Point3D();
        Point3D point3d = new Point3D(1, 2, 3);

        System.out.println(point3d);

    }
}