public class TestBai5{
    public static void main(String [] args){
        Employee employee1 = new Employee();
        Employee employee = new Employee("521H0324", "Nguyen Van Truong", 1.5, 2019, 1);

        System.out.println(employee);
    }
}