public class TestBai6{
    public static void main(String [] args){
        Manager manager1 = new Manager();
        Manager manager = new Manager("521H0324", "Nguyen Van Truong", 1.5, "Head", 5.0, 2020, 0);

        System.out.println(manager);
    }
}